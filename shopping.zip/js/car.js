new Vue({
	el:'#headTitle',
	data:{
		titles:[
			{text:'商品信息'},
			{text:'商品金额'},
			{text:'商品数量'},
			{text:'总金额'},
			{text:'编辑'}
		]
	}
})

Vue.component('todo-item',{
	props:['todo'],
	template:'<div><input type="radio" :checked="checkeds"  @click="checkClick"><div>{{todo}}</div></div>',
	data:function(){
		return {
			checkeds:false
		}
	},
	methods:{
		checkClick:function(){
			this.checkeds = !this.checkeds;
		}
	}
})

new Vue({
	el:'#starlist',
	data:{
		productlist:[]
	},
	mounted:function(){
		 this.$nextTick(function() {
     		 this.cartView();
   		 })
	},
	methods:{
		cartView:function(){
			var _t=this;
			this.$http.get("index.json").then(function(res){
				_t.productlist=res.body.carlist;
			});
		}
	}
})